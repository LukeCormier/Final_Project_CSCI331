'use strict'

const { post } = require("@adonisjs/framework/src/Route/Manager");

//bring in model
const Event = use('App/Models/Event')
//bring in validator
const { validate } = use('Validator')

class EventController {
    async index({ view }) {
        /* const events = [
            {title: 'Event One', body:'This is event one'},
            {title: 'Event Two', body:'This is event two'},
            {title: 'Event Three', body:'This is event three'}
        ] */

        const events = await Event.all();

        return view.render('events.index', {
            title: 'Latest Events',
            events: events.toJSON()
        })
    }

    async details({params, view}) {
        const event = await Event.find(params.id)
        return view.render('events.details', {event:event})
    }

    async add({ view }) {
        return view.render('events.add')
    }

    async store({ request, response, session }){
        //Validate input
        const validation = await validate(request.all(), {
            title: 'required|min:3|max:255',
            body: 'required|min:3'
        })

        if(validation.fails()){
            session.withErrors(validation.messages()).flashAll()
            return response.redirect('back')
        }

        const event = new Event();

        event.title = request.input('title')
        event.body = request.input('body')

        await event.save()

        session.flash({ notification: 'Event created!' })

        return response.redirect('/events')
    }

    async edit({ params, view }) {
        const event = await Event.find(params.id)

        return view.render('events.edit', { event: event})
    }

    async update({ params, request, response, session }) {
        //Validate input
        const validation = await validate(request.all(), {
            title: 'required|min:3|max:255',
            body: 'required|min:3'
        })

        if(validation.fails()){
            session.withErrors(validation.messages()).flashAll()
            return response.redirect('back')
        }

        const event = await Event.find(params.id)

        event.title = request.input('title')
        event.body = request.input('body')

        await event.save()

        session.flash({ notification: "Event Updated!" })

        return response.redirect('/events')

    }

    async destroy({ params, session, response}) {
        const event = await Event.find(params.id)

        await event.delete()

        session.flash({ notification: "Event Deleted!" })

        return response.redirect('/events')
    }
}

module.exports = EventController
