'use strict'

const { RouteResource } = require('@adonisjs/framework/src/Route/Manager');

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

Route.on('/').render('home')

Route.on('/about').render('about')

Route.group(() => {
  Route.get("logout", "SessionController.delete");

  Route.post('register', "UserController.store")

  Route.get('/events', 'EventController.index')

  Route.get('/events/add', 'EventController.add')

  Route.get('/events/edit/:id', 'EventController.edit')

  Route.get('/events/:id', 'EventController.details')

  Route.post('/events', 'EventController.store')

  Route.put('/events/:id', 'EventController.update')

  Route.delete('/events/:id', 'EventController.destroy')

}).middleware(["auth"]);

Route.get('register', "UserController.create")

Route.get("login", "SessionController.create");

Route.post("login", "SessionController.store");

Route.post("logout", "SessionController.delete");





/* Route.get('/test', () => 'Hello World')

Route.get('/test2', function(){
    return 'Hello There'
})

Route.get('/test/:id?', async ({ params }) => {
    if (params.id) {
      return `Viewing events with id ${params.id}`
    }
    return 'Viewing all events'
  }) */